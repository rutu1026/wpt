// server.js

const express = require("express");
const port = 3001;
const db = require("./db");
const bcrypt = require('bcryptjs');
const bodyParser = require('body-parser');
const jwt = require("jsonwebtoken");
const secret_key = '123456789';

// ✅ Import auth only ONCE
const auth = require("./authenticate");

const app = express();
app.use(bodyParser.json());

// ✅ REGISTER
app.post('/register', async (req, res) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return res.status(400).send("Username and password are required");
    }

    try {
        const hashedPassword = await bc.hash(password, 10); // ✅ use `bc`
        const sql = "INSERT INTO login (username, password) VALUES (?, ?)";

        db.query(sql, [username, hashedPassword], (err, result) => {
            if (err) {
                console.log("Error inserting user:", err.message);
                return res.status(500).send('Unable to register user');
            }

            return res.status(200).send('Registered successfully');
        });
    } catch (error) {
        console.error("Hashing error:", error.message);
        return res.status(500).send('Error while hashing password');
    }
});


// ✅ LOGIN
app.post('/login', async (req, res) => {
    const { username, password } = req.body;

    const sql = "SELECT * FROM login WHERE username = ?";
    db.query(sql, [username], async (err, result) => {
        if (err) {
            console.log("Error fetching user:", err.message);
            return res.status(500).send('Unable to login');
        }

        if (result.length === 0) {
            return res.status(401).send({ success: false, message: "User not found" });
        }

        const user = result[0];
        const passwordMatched = await bcrypt.compare(password, user.password);

        if (passwordMatched) {
            const token = jwt.sign(
                { userId: user.id, username: user.username },
                secret_key,
                { expiresIn: '30m' }
            );

            return res.status(200).send({ success: true, message: 'Login successful', token });
        } else {
            return res.status(401).send({ success: false, message: "Invalid credentials" });
        }
    });
});

// ✅ GET STUDENTS (protected)
app.get('/getStudents', auth, (req, res) => {
    const sql = 'SELECT * FROM students';

    db.query(sql, (err, result) => {
        if (err) {
            console.error("Error fetching students:", err.message);
            return res.status(500).send('Error while fetching data');
        }

        return res.status(200).json({ success: true, data: result });
    });
});

app.listen(port, () => {
    console.log("Server running on port", port);
});
