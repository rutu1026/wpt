
const mysql = require("mysql2");

const con = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'Kadam@1026',
    port: 3306,
    database: 'students'
});

con.connect((err)=>{
    if(err){
        console.error("Error connecting to the database:", err.message);
        return;
    }
    console.log("connected to db");
});

module.export = con;